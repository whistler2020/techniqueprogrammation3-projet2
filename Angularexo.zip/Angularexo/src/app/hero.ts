export interface Hero {
    _id: String;
    nom: String
}
