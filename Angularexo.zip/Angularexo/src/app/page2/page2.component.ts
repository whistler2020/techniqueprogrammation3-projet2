import { Component, OnInit } from '@angular/core';
import { Hero } from '../hero';

@Component({
  selector: 'app-page2',
  templateUrl: './page2.component.html',
  styleUrls: ['./page2.component.css']
})
export class Page2Component implements OnInit {
  hero1: Hero = {_id:'', nom: 'mon premier hero'};
  hero2: Hero = {_id:'', nom: 'Mon deuxième héro'};
  hero3: Hero = {_id:'', nom: 'Mon troisieme héro'};
  hero4: Hero = {_id:'', nom: 'Mon quatrieme héro'};
  hero5: Hero = {_id:'', nom: 'Mon cinquieme héro'};  

  constructor() { }

  ngOnInit(): void {
  }

}
